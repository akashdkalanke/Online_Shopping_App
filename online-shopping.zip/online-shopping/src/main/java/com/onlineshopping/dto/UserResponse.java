package com.onlineshopping.dto;

public class UserResponse {

}
